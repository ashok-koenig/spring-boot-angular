package com.example.mvc_jpa_crud_demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcJpaCrudDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcJpaCrudDemoApplication.class, args);
	}

}
