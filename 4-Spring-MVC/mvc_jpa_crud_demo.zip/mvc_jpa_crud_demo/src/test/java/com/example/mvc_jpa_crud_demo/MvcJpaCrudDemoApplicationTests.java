package com.example.mvc_jpa_crud_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcJpaCrudDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
